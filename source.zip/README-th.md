# US Stock Ranker — คู่มือใช้งานและเปิดเว็บฟรี

เว็บคัดกรองหุ้นสหรัฐสำหรับศึกษาการลงทุนระยะยาว พร้อมตัวเก็บข้อมูลและงานอัปเดตอัตโนมัติ ใช้หน้าเว็บแบบ static จึงไม่ต้องเปิดคอมพิวเตอร์หรือเช่าเครื่องที่ทำงานทั้งวัน

**สถานะการส่งมอบ:** ไฟล์ชุดนี้พร้อมทดลองในเครื่องและนำขึ้นบัญชีของคุณ งานอัปเดตรายวันบน GitHub จะเริ่มทำงานหลังตั้งค่า repository ตามขั้นตอนด้านล่าง ตรวจป้ายสถานะการเผยแพร่และวันที่ข้อมูลบนหน้าเว็บเสมอ ถ้าเป็นโหมดสาธิต ตัวเลขนั้นใช้ทดลองหน้าจอเท่านั้น

## ระบบทำงานอย่างไร

```text
SEC EDGAR (งบ) + แหล่งราคาหุ้น
          ↓ งาน Python บน GitHub Actions วันละครั้ง
ตรวจข้อมูล → คำนวณตัวชี้วัด → บันทึก dist/data/latest.json
          ↓ เมื่อการทดสอบและดึงข้อมูลผ่าน
GitHub Pages → เปิดเว็บบนคอมพิวเตอร์และมือถือได้ตลอด
```

หน้าเว็บเปิดได้แม้งานเก็บข้อมูลไม่ได้กำลังทำงาน ราคากับอันดับเป็น snapshot ตามเวลาที่แสดง ไม่ใช่ราคาซื้อขายแบบเรียลไทม์ การปรับน้ำหนักบนหน้าเว็บคำนวณใหม่ในเบราว์เซอร์ ไม่ได้ดึงงบใหม่หรือส่งคำสั่งซื้อหุ้น

โครงสร้างไฟล์หลัก:

```text
us-stock-ranker/
├── .github/workflows/update.yml  งานทดสอบ อัปเดต และเผยแพร่
├── dist/index.html              หน้าเว็บ
├── dist/data/latest.json        ข้อมูลที่หน้าเว็บอ่าน
├── scripts/collect.py            ตัวเก็บข้อมูล
├── scripts/universe.json         รายชื่อหุ้นและกลุ่มธุรกิจที่ติดตาม
├── scripts/scoring.py            นิยามตัวชี้วัดและคะแนน
├── tests/                       การทดสอบกติกาสำคัญ
└── README-th.md                  คู่มือนี้
```

## เปิดดูในเครื่อง

ถ้ามี Python 3.12 ขึ้นไป ให้เปิด Terminal ในโฟลเดอร์ `us-stock-ranker` แล้วรัน:

```powershell
py -m http.server 8000 --directory dist
```

จากนั้นเปิด `http://localhost:8000` ในเบราว์เซอร์ ปิด server ด้วย `Ctrl+C` ถ้าเครื่องใช้คำสั่ง `python` ให้แทน `py` ด้วย `python` ไม่ต้องติดตั้งแพ็กเกจ Python เพิ่ม

อย่าดับเบิลคลิก HTML เพื่อใช้งานผ่าน `file://` เพราะการอ่าน JSON อาจถูกเบราว์เซอร์ปิดกั้น

## เปิดออนไลน์ด้วย GitHub Free

ตรวจเอกสารผู้ให้บริการเมื่อ 15 ตุลาคม 2026: GitHub Pages ใช้ได้กับ public repository บน GitHub Free และงานที่ใช้ standard GitHub-hosted runner ใน public repository ไม่มีค่า runner ตามเงื่อนไขปัจจุบัน ชุดนี้ใช้ `ubuntu-latest` ไม่ใช้ larger runner หรือบริการเสียเงิน [GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages), [GitHub Actions billing](https://docs.github.com/en/billing/concepts/product-billing/github-actions)

### หากใช้ repository ที่จัดเตรียมไว้แบบ ZIP

[Repository ที่เตรียมไว้](https://github.com/kardphon2548/us-stock-ranker) เก็บแอปครบชุดใน `source.zip` และมี workflow ที่ราก `.github/workflows/update.yml` สำหรับแตก ZIP ไปที่ `project/` ก่อนรัน การแก้ไขแอปให้ดาวน์โหลด ZIP → Extract All → แก้ไฟล์ → บีบอัดสิ่งที่อยู่ข้างในเป็น `source.zip` ใหม่ → อัปโหลดทับ → Run workflow เปิด ZIP แล้วต้องเห็น `dist`, `scripts` และ `tests` ทันที ไม่ซ้อนใต้โฟลเดอร์อีกชั้น อ่านวิธีตั้ง Secret และ Pages ต่อจากขั้นตอนที่ 2 ด้านล่าง

หากแก้ workflow สำหรับ repository แบบ ZIP ให้แก้ `.github/workflows/update.yml` บน GitHub โดยตรง ไฟล์ workflow ที่อยู่ *ข้างใน* ZIP เป็นฉบับสำหรับโครงสร้างโฟลเดอร์ปกติและไม่ได้ถูก GitHub เรียกใช้งานเอง การปิด `refresh_data` จะใช้ snapshot ใน ZIP จึงควรตรวจวันที่ก่อนเผยแพร่

ขั้นตอนที่ 1 ต่อไปนี้เป็นอีกวิธีหนึ่งสำหรับสร้าง repository ใหม่โดยวางไฟล์เป็นโฟลเดอร์ปกติ ไม่ต้องทำซ้ำหากใช้ repository แบบ ZIP ที่จัดเตรียมไว้

### 1. นำไฟล์ขึ้น repository ของคุณ

1. ลงชื่อเข้าใช้ [GitHub](https://github.com/) แล้วเลือก **New repository**
2. ตั้งชื่อ เช่น `us-stock-ranker` เลือก **Public** และกด **Create repository**
3. ใช้ **uploading an existing file** หรือ **Add file → Upload files** แล้วอัปโหลดสิ่งที่อยู่ *ข้างใน* โฟลเดอร์ `us-stock-ranker` ให้ `dist`, `scripts`, `tests` และ `.github` อยู่ที่ราก repository ไม่ซ้อนใต้ `outputs/us-stock-ranker` อีกชั้น
4. กด **Commit changes** หากอัปโหลดผ่านเว็บไม่เห็น `.github` ให้สร้างไฟล์ผ่าน **Add file → Create new file** ตั้งชื่อ `.github/workflows/update.yml` แล้วคัดลอกเนื้อหาจากไฟล์ที่ให้มา
5. ตรวจว่าเปิด `.github/workflows/update.yml` และ `dist/index.html` บน GitHub ได้ อัปโหลดเฉพาะโฟลเดอร์ระบบนี้ เพราะ repository แบบ Public เปิดให้ทุกคนดูไฟล์ได้

สำหรับผู้ใช้ Git อยู่แล้ว รันจากโฟลเดอร์ระบบนี้ โดยแทน `YOUR_NAME` ด้วยชื่อบัญชีของคุณ:

```powershell
git init
git add .
git commit -m "Add US stock ranker"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/us-stock-ranker.git
git push -u origin main
```

### 2. ตั้งข้อมูลติดต่อสำหรับ SEC

1. ใน repository เลือก **Settings → Secrets and variables → Actions → Secrets**
2. กด **New repository secret**
3. Name: `SEC_USER_AGENT`
4. Secret: ชื่อแอปและอีเมลติดต่อจริงของคุณ เช่น `USStockRanker contact@example.com` โดยเปลี่ยนอีเมลตัวอย่างก่อนใช้
5. กด **Add secret**

SEC API ไม่ต้องมี API key แต่กำหนดให้ระบบอัตโนมัติระบุตัวตนและเคารพข้อจำกัดการเข้าถึง ตัวเก็บข้อมูลทำงานฝั่ง job เพราะ SEC ไม่รองรับ CORS สำหรับการเรียกจากหน้าเว็บโดยตรง เก็บข้อมูลติดต่อเป็น Secret เพื่อไม่ใส่อีเมลลงในโค้ดหรือ JSON ที่เผยแพร่ [SEC API](https://www.sec.gov/search-filings/edgar-application-programming-interfaces), [SEC Fair Access](https://www.sec.gov/about/webmaster-frequently-asked-questions)

### 3. เปิด GitHub Pages และรันครั้งแรก

1. เลือก **Settings → Pages**
2. ที่ **Build and deployment → Source** เลือก **GitHub Actions**
3. ไปแท็บ **Actions** ถ้ามีปุ่มเปิดใช้ workflows ให้กดเปิด
4. เลือก **Update stock ranking and publish**
5. กด **Run workflow** เลือก default branch และเปิด `refresh_data` ไว้ แล้วกดรัน
6. รอให้ `build` และ `deploy` ผ่าน เปิด run นั้นแล้วกดลิงก์ใต้ `github-pages` หรือกลับไปดู **Settings → Pages**

URL โดยทั่วไปคือ `https://YOUR_NAME.github.io/us-stock-ranker/` ใช้โดเมนนี้ได้โดยไม่ซื้อโดเมนเอง เปิดจากมือถือได้ และเพิ่มเป็นทางลัดบนหน้าจอโฮมผ่านเมนูเบราว์เซอร์

หากต้องการดูหน้าเว็บก่อนตั้งค่าแหล่งข้อมูล ให้รันแบบปิด `refresh_data` ได้ วิธีนี้เผยแพร่ **snapshot ที่อยู่ใน repository** เท่านั้น อาจเป็นข้อมูลเก่าหรือข้อมูลสาธิต ไม่ใช่การอัปเดตราคาหุ้น และอย่ากดวิธีนี้ทับข้อมูลออนไลน์ที่ใหม่กว่าโดยไม่ตรวจวันที่

### 4. การอัปเดตอัตโนมัติ

ไฟล์ workflow ตั้งให้รันวันจันทร์–ศุกร์เวลา **22:40 UTC หรือ 05:40 น. ของวันอังคาร–เสาร์ในไทย** ซึ่งอยู่หลังเวลาปิดตลาดปกติของสหรัฐทั้งสองฤดูกาล การรันในวันหยุดตลาดอาจได้ราคาปิดวันทำการก่อนหน้า

- ทดสอบกติกาก่อนเก็บข้อมูลทุกครั้ง
- `collect.py --strict` หยุดรอบนั้นหากแหล่งข้อมูลดิบของหุ้นที่กำหนดดึงไม่ครบ หน้าเว็บออนไลน์ยังใช้ snapshot เดิม
- รายการบัญชีที่บริษัทไม่รายงานยังแสดงว่าไม่มีข้อมูล และอาจพักอันดับหุ้นนั้น ไม่สร้างตัวเลขทดแทน
- ข้อมูลใหม่เผยแพร่เป็น Pages artifact โดยตรง ไม่ต้องบันทึกราคาทุกวันเป็น commit และไม่ต้องสร้าง Personal Access Token

**ข้อจำกัดของการปล่อยรันฟรี:** GitHub ระบุว่า schedule อาจล่าช้าหรือบางงานถูกข้ามเมื่อระบบหนาแน่น และ public repository ที่ไม่มีกิจกรรม 60 วันจะถูกปิด scheduled workflow อัตโนมัติ ตารางรันจึงไม่ใช่การรับประกันเวลาหรือการทำงานตลอดไป ควรตรวจแท็บ Actions และวันที่ข้อมูลอย่างน้อยเดือนละครั้ง หากถูกปิดให้เลือก workflow แล้วกด **Enable workflow** ก่อนรันใหม่ [ข้อจำกัด schedule](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#schedule), [เปิดและปิด workflow](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/disable-and-enable-workflows)

เงื่อนไขราคา โควตา และนโยบายอาจเปลี่ยนได้ การใช้งานต้องอยู่ในข้อจำกัดและข้อตกลงของแต่ละบริการ ไม่ควรตีความว่าได้รับประกันฟรีถาวรหรือมี SLA

## อัปเดตข้อมูลในเครื่องด้วยตัวเอง

เปิด PowerShell ในโฟลเดอร์ระบบ แล้วตั้งค่าติดต่อสำหรับ session นี้:

```powershell
$env:SEC_USER_AGENT = 'USStockRanker your-real-contact@example.com'
py -m unittest discover -s tests -v
py scripts/collect.py --strict
```

ตรวจผลลัพธ์และวันที่ใน `dist/data/latest.json` แล้วรีเฟรชหน้าเว็บ หากคำสั่งคืน error ให้ดูข้อความข้อผิดพลาดก่อนลองใหม่ ตัวเก็บข้อมูลเขียนไฟล์แบบ atomic และโหมด strict จะไม่แทนที่ข้อมูลเดิมเมื่อการดึงข้อมูลไม่ครบ

## วิธีอ่านคะแนน

น้ำหนักเริ่มต้นแบ่งเป็นคุณภาพธุรกิจ 35%, การเติบโต 20%, ความเหมาะสมของราคา 25%, ฐานะการเงิน 15% และการเพิ่มจำนวนหุ้น 5% เป็นสมมติฐานสำหรับทดสอบ ไม่ใช่น้ำหนักที่พิสูจน์ว่าให้ผลตอบแทนดีที่สุด

รุ่นแรกใช้ **งบประจำปีล่าสุด (FY)** และประวัติงบรายปีสำหรับตัวชี้วัดระยะยาว ยังไม่ได้รวมงบ 4 ไตรมาสล่าสุดเป็น TTM ดังนั้นราคาหุ้นเปลี่ยนทุกวันได้ แต่ตัวกำไรอาจตามหลังการประกาศรายไตรมาส ตัวหารมูลค่าตลาดและ EV ใช้จำนวนหุ้นเฉลี่ย diluted จากงบเป็นค่าประมาณ ซึ่งอาจต่างจากจำนวนหุ้นปัจจุบัน

คะแนนเป็น percentile ภายใน sector เมื่อมีค่าที่ใช้ได้อย่างน้อย 5 บริษัท มิฉะนั้นใช้หุ้นที่มีค่าใน sample universe ทั้งหมด และระบุกลุ่มกับจำนวนที่ใช้เทียบไว้ รุ่นนี้ยังไม่ใช่การจัดอันดับหุ้นสหรัฐครบทั้งตลาดหรือเทียบอุตสาหกรรมย่อยที่ตรวจสอบครบถ้วน

ใช้คะแนนเพื่อจัดลำดับบริษัทที่จะอ่านงบต่อ ตรวจค่าจริง อายุข้อมูล เหตุผลพักอันดับ และกลุ่มที่ใช้เปรียบเทียบประกอบ หุ้นที่ได้อันดับสูงในกลุ่มเล็กอาจไม่ได้ดีกว่าหุ้นทั้งตลาด ค่า P/E ติดลบไม่ตีความเป็นหุ้นราคาถูก และธนาคาร ประกัน REIT รวมถึงบริษัทที่ยังขาดทุนต้องใช้โมเดลเฉพาะ

ตัวคัดกรองนี้ไม่ได้ประเมินความได้เปรียบทางการแข่งขัน คุณภาพผู้บริหาร หรือความเสี่ยงเฉพาะบริษัทได้ครบ และยังต้องทำ backtest แบบใช้ข้อมูลตามวันที่เผยแพร่จริงก่อนอ้างผลการลงทุน

## ข้อมูลฟรีมีข้อจำกัดอะไรบ้าง

- **SEC EDGAR:** เป็นข้อมูลที่บริษัทยื่นจริง งบมีหน่วย ปฏิทินบัญชี รายการแก้ไข และชื่อ tag แตกต่างกัน ตรวจตัวเลขสำคัญกับ 10-K/10-Q ก่อนตัดสินใจ การขยายรายชื่อหุ้นต้องตรวจ mapping และความครบถ้วนเพิ่มเติม
- **ราคาจาก Yahoo Finance:** การเรียก endpoint นี้ไม่ใช่บริการข้อมูลตลาดที่มีสัญญาและ SLA อาจถูกจำกัดหรือเปลี่ยนโดยไม่แจ้ง โครงการ yfinance ซึ่งใช้งานแหล่งเดียวกันระบุว่าไม่ได้เกี่ยวข้องกับ Yahoo และการใช้ข้อมูลอยู่ภายใต้เงื่อนไขของ Yahoo โดยเน้นการใช้ส่วนบุคคล จึงเหมาะเริ่มต้นเพื่อศึกษาส่วนตัว ไม่ควรถือว่าการเข้าถึงฟรีให้สิทธิ์เผยแพร่ราคาต่อหรือเปิดบริการเชิงพาณิชย์โดยอัตโนมัติ ตรวจสิทธิ์กับผู้ให้บริการก่อนเปิดใช้สาธารณะ [คำอธิบายจากโครงการ yfinance](https://github.com/ranaroussi/yfinance)
- **การเผยแพร่:** Public GitHub Pages เปิดให้คนอื่นเข้าถึงหน้าเว็บและ JSON ได้ หากต้องการให้เป็นบริการสาธารณะจริง ควรใช้แหล่งข้อมูลที่อนุญาตการแสดงผลและเผยแพร่ต่ออย่างชัดเจน แล้วเปลี่ยนส่วนดึงราคาให้ตรงกับสิทธิ์นั้น

## ทางเลือกเมื่อขยายระบบ

Cloudflare Pages มีแผน Free และ Workers รองรับ Cron Triggers แต่ต้องออกแบบตัวเก็บข้อมูลกับที่เก็บ snapshot ใหม่ให้เหมาะกับเวลาประมวลผลและโควตา ไม่ได้รันสคริปต์ Python ชุดนี้ตรง ๆ บน Pages แผน Workers Free ปัจจุบันมีขีดจำกัด 100,000 requests/วัน และ CPU ต่อ invocation ค่อนข้างต่ำ การเลือก GitHub Actions ในรุ่นนี้ช่วยให้เริ่มด้วย Python ตามรอบเวลาได้ตรงกว่า [Cloudflare Pages limits](https://developers.cloudflare.com/pages/platform/limits/), [Workers pricing](https://developers.cloudflare.com/workers/platform/pricing/), [Cron Triggers](https://developers.cloudflare.com/workers/configuration/cron-triggers/)

หากต้องการทั้งตลาดหลายพันหุ้น อัปเดตทุกนาที หรือผู้ใช้หลายคน ควรประเมินสิทธิ์ข้อมูลและค่าใช้จ่ายใหม่ก่อนเพิ่มความถี่ ขนาด universe และจำนวนตัวชี้วัด การเปิดหน้าเว็บตลอดกับการมีข้อมูลราคาตลาดครบถ้วนแบบเรียลไทม์เป็นคนละค่าใช้จ่ายกัน

## แก้ปัญหาที่พบบ่อย

| อาการ | วิธีตรวจและแก้ |
|---|---|
| ไม่เห็น workflow | ตรวจ `.github/workflows/update.yml` อยู่ที่ราก repository และอยู่บน default branch |
| Pages 404 | ตั้ง Source เป็น GitHub Actions และรอ deploy ผ่าน ตรวจ URL ว่ามีชื่อ repository ต่อท้าย |
| SEC_USER_AGENT missing | เพิ่ม repository secret ตามชื่อที่กำหนด แล้ว Run workflow ใหม่ |
| SEC 403 หรือ 429 | ตรวจข้อมูลติดต่อ ลดความถี่ และรอแล้วลองใหม่ หลีกเลี่ยงรันซ้อนหรือเพิ่มอัตราคำขอ |
| ดึงราคาหรืองบไม่ได้ | เปิดรายละเอียดขั้น Collect ใน Actions; snapshot เดิมยังแสดงอยู่ ตรวจสถานะผู้ให้บริการก่อนรันใหม่ |
| ไม่มีอันดับบางหุ้น | ดูเหตุผลข้อมูลไม่ครบหรืออัตราส่วนใช้ไม่ได้; อย่าเติมศูนย์แทนค่าที่หาย |
| วันที่ไม่ขยับ | ตรวจวันหยุดตลาด ผล workflow ล่าสุด และ scheduled workflow ยังเปิดอยู่หรือไม่ |
| เปิด HTML แล้วข้อมูลไม่ขึ้น | ใช้ local HTTP server ตามคำสั่งด้านบน |

รุ่นนี้ใช้ official Actions majors ที่ตรวจจาก release ปัจจุบัน ได้แก่ checkout v7, setup-python v7, configure-pages v6, upload-pages-artifact v5 และ deploy-pages v5 ตรวจ release และ changelog ก่อนอัปเกรดในอนาคต
