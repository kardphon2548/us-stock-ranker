import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from scoring import METRIC_DEFS, WEIGHTS, cagr, compute_metrics, percentile, score_stocks
from collect import fact_series, main, normalize_annual, parse_price


def annual_fixture():
    return [{"start": f"{year}-01-01", "end": f"{year}-12-31", "filing_date": f"{year + 1}-02-01",
             "revenue": 100 * 1.1 ** (year - 2019), "operating_income": 20, "cfo": 24,
             "capex": 4, "eps": 2 * 1.1 ** (year - 2019), "shares": 10, "tax": 4,
             "pretax": 20, "debt": 30, "equity": 70, "cash": 10, "interest": 2, "da": 5}
            for year in range(2019, 2025)]


class PercentileTests(unittest.TestCase):
    def test_higher_and_inverse(self):
        self.assertEqual(percentile(10, [10, 20, 30]), 0)
        self.assertEqual(percentile(10, [10, 20, 30], "lower"), 100)
        self.assertEqual(percentile(20, [10, 20, 30]), 50)

    def test_ties_singletons_missing(self):
        self.assertEqual(percentile(3, [3, 3, 3]), 50)
        self.assertEqual(percentile(3, [3]), 50)
        self.assertIsNone(percentile(None, [3]))
        self.assertIsNone(percentile(3, []))


class AccountingTests(unittest.TestCase):
    def test_weight_sum_and_complete_model(self):
        self.assertEqual(sum(WEIGHTS.values()), 100)
        self.assertEqual(len(WEIGHTS), 11)
        metrics = compute_metrics(annual_fixture(), 50)
        self.assertTrue(all(metric["value"] is not None for metric in metrics.values()))
        self.assertAlmostEqual(metrics["revenue_cagr"]["value"], .10)
        self.assertAlmostEqual(metrics["fcf_yield"]["value"], .04)
        self.assertAlmostEqual(metrics["roic"]["value"], 16 / 90)

    def test_missing_does_not_reweight(self):
        metrics = compute_metrics(annual_fixture(), 50)
        metrics["roic"]["value"] = None
        stock = {"ticker": "TEST", "sector": "Tech", "metrics": metrics}
        score_stocks([stock])
        self.assertEqual(stock["coverage"], 85)
        self.assertEqual(stock["status"], "unranked")
        self.assertIsNone(stock["score"])

    def test_negative_eps_is_not_cheap(self):
        annual = annual_fixture()
        annual[-1]["eps"] = -3
        metrics = compute_metrics(annual, 50)
        self.assertIsNone(metrics["earnings_yield"]["value"])
        self.assertIsNone(metrics["eps_cagr"]["value"])

    def test_missing_year_blocks_five_year_cagr(self):
        annual = annual_fixture()
        annual.pop(2)
        self.assertIsNone(compute_metrics(annual, 50)["revenue_cagr"]["value"])
        self.assertIsNone(cagr([1, 2, 3]))

    def test_nonpositive_invested_capital_blocks_roic(self):
        annual = annual_fixture()
        annual[-1]["cash"] = 101
        self.assertIsNone(compute_metrics(annual, 50)["roic"]["value"])

    def test_split_adjustment_respects_filing_date(self):
        annual = annual_fixture()
        annual[-1]["eps_filed"] = "2025-07-01"
        annual[-1]["shares_filed"] = "2025-07-01"
        # Old source predates a 2-for-1 split; current source already restated.
        for row in annual[:-1]:
            row["eps"] *= 2
            row["shares"] /= 2
        metrics = compute_metrics(annual, 50, [{"date": "2025-06-01", "ratio": 2}])
        self.assertAlmostEqual(metrics["eps_cagr"]["value"], .10)
        self.assertAlmostEqual(metrics["shares_cagr"]["value"], 0)

    def test_zero_interest_only_when_reported(self):
        annual = annual_fixture()
        del annual[-1]["interest"]
        self.assertIsNone(compute_metrics(annual, 50)["interest_coverage"]["value"])
        annual[-1]["interest"] = 0
        self.assertEqual(compute_metrics(annual, 50)["interest_coverage"]["value"], 100)

    def test_annual_cashflow_never_sums_ytd(self):
        facts = {"facts": {"us-gaap": {"NetCashProvidedByUsedInOperatingActivities": {"units": {"USD": [
            {"start": "2024-01-01", "end": "2024-03-31", "val": 10, "form": "10-Q", "filed": "2024-05-01"},
            {"start": "2024-01-01", "end": "2024-06-30", "val": 25, "form": "10-Q", "filed": "2024-08-01"},
            {"start": "2024-01-01", "end": "2024-12-31", "val": 60, "form": "10-K", "filed": "2025-02-01"},
            {"start": "2024-01-01", "end": "2024-12-31", "val": 61, "form": "10-K", "filed": "2026-02-01"},
        ]}}}}}
        series = fact_series(facts, ["NetCashProvidedByUsedInOperatingActivities"], as_of="2025-12-31")
        self.assertEqual(list(series), ["2024-12-31"])
        self.assertEqual(series["2024-12-31"]["val"], 60)

    def test_total_debt_not_double_counted(self):
        usgaap = {}
        for tag, val, duration in [("Revenues", 100, True), ("LongTermDebtAndFinanceLeaseObligationsIncludingCurrentPortion", 50, False),
                                   ("LongTermDebtCurrent", 10, False), ("LongTermDebtNoncurrent", 40, False), ("ShortTermBorrowings", 5, False)]:
            raw = {"end": "2024-12-31", "val": val, "form": "10-K", "filed": "2025-02-01"}
            if duration:
                raw["start"] = "2024-01-01"
            usgaap[tag] = {"units": {"USD": [raw]}}
        annual = normalize_annual({"facts": {"us-gaap": usgaap}})
        self.assertEqual(annual[0]["debt"], 55)

    def test_newer_alias_restatement_wins_over_priority(self):
        def tagged(value, filed):
            return {"units": {"USD": [{"start": "2024-01-01", "end": "2024-12-31", "val": value, "form": "10-K", "filed": filed}]}}
        facts = {"facts": {"us-gaap": {"Preferred": tagged(100, "2025-02-01"), "Fallback": tagged(95, "2026-02-01")}}}
        result = fact_series(facts, ["Preferred", "Fallback"], as_of="2026-03-01")
        self.assertEqual(result["2024-12-31"]["val"], 95)

    def test_separate_da_requires_both_nonoverlapping_components(self):
        def tagged(value):
            return {"units": {"USD": [{"start": "2024-01-01", "end": "2024-12-31", "val": value, "form": "10-K", "filed": "2025-02-01"}]}}
        facts = {"facts": {"us-gaap": {"Revenues": tagged(100), "Depreciation": tagged(8)}}}
        self.assertNotIn("da", normalize_annual(facts)[0])
        facts["facts"]["us-gaap"]["AmortizationOfIntangibleAssets"] = tagged(2)
        annual = normalize_annual(facts)
        self.assertEqual(annual[0]["da"], 10)
        self.assertEqual(annual[0]["sources"]["da"]["evidence_label"], "derived_calculation")

    def test_sector_fallback_is_visible(self):
        stocks = [{"ticker": f"T{i}", "sector": str(i), "metrics": compute_metrics(annual_fixture(), 30 + i)} for i in range(3)]
        score_stocks(stocks)
        self.assertEqual(stocks[0]["metrics"]["earnings_yield"]["comparison_group"], "sample universe")
        self.assertEqual(stocks[0]["metrics"]["earnings_yield"]["sample_n"], 3)


class PublishingSafetyTests(unittest.TestCase):
    def test_strict_failure_preserves_previous_snapshot(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            root = Path(directory)
            universe = root / "universe.json"
            output = root / "latest.json"
            universe.write_text('[{"ticker":"TEST","cik":"1","sector":"Test"}]')
            output.write_text('{"sentinel":true}')
            with patch("collect.collect", return_value=([], ["source unavailable"])):
                code = main(["--strict", "--universe", str(universe), "--output", str(output), "--cache-dir", str(root / "cache")])
            self.assertEqual(code, 1)
            self.assertEqual(json.loads(output.read_text()), {"sentinel": True})


if __name__ == "__main__":
    unittest.main()
