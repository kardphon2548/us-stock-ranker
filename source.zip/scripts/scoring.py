"""Deterministic, conservative scoring for an educational long-term equity screen.

All percentage metric values are fractions (0.12 means 12%). Missing metrics are
never converted to zero or silently reweighted. The score is a relative screen,
not an expected return or a buy recommendation.
"""
from __future__ import annotations

import math
from statistics import mean, pstdev
from datetime import date


METRIC_DEFS = {
    "roic": {"label": "ROIC เฉลี่ย 3 ปี", "weight": 15, "unit": "percent", "direction": "higher", "group": "quality", "description": "กำไรดำเนินงานหลังภาษี / เงินลงทุนเฉลี่ยต้นและปลายปี (หนี้ + ส่วนผู้ถือหุ้น − เงินสด); เฉลี่ย 3 ปี"},
    "fcf_margin": {"label": "FCF Margin เฉลี่ย 3 ปี", "weight": 10, "unit": "percent", "direction": "higher", "group": "quality", "description": "(กระแสเงินสดดำเนินงาน − Capex) / รายได้ เฉลี่ย 3 ปี"},
    "operating_margin_stability": {"label": "ความผันผวน Operating Margin 5 ปี", "weight": 10, "unit": "percent", "direction": "lower", "group": "quality", "description": "ส่วนเบี่ยงเบนมาตรฐานของกำไรดำเนินงาน / รายได้ 5 ปี; ต่ำดีกว่า"},
    "revenue_cagr": {"label": "รายได้เติบโตต่อปี 5 ปี", "weight": 10, "unit": "percent", "direction": "higher", "group": "growth", "description": "CAGR จากรายได้ 6 ปีงบประมาณต่อเนื่อง"},
    "eps_cagr": {"label": "Diluted EPS เติบโตต่อปี 5 ปี", "weight": 10, "unit": "percent", "direction": "higher", "group": "growth", "description": "CAGR 5 ปีของกำไรต่อหุ้นปรับ stock split; ต้องมีกำไรทุกปี"},
    "earnings_yield": {"label": "Earnings Yield (FY)", "weight": 10, "unit": "percent", "direction": "higher", "group": "valuation", "description": "Diluted EPS ปีงบล่าสุดปรับ split / ราคาปิด; กำไรติดลบใช้ไม่ได้"},
    "fcf_yield": {"label": "FCF Yield (FY)", "weight": 10, "unit": "percent", "direction": "higher", "group": "valuation", "description": "FCF ปีงบล่าสุด / (ราคาปิด × diluted shares ปีงบล่าสุดปรับ split); ใช้จำนวนหุ้นเฉลี่ยเป็นค่าประมาณ"},
    "ebit_ev": {"label": "EBIT / EV (FY)", "weight": 5, "unit": "percent", "direction": "higher", "group": "valuation", "description": "กำไรดำเนินงาน / (ราคาปิด × diluted shares ปีงบล่าสุด + หนี้ − เงินสด); EV เป็นค่าประมาณ"},
    "net_debt_ebitda": {"label": "Net Debt / EBITDA", "weight": 10, "unit": "ratio", "direction": "lower", "group": "balance", "description": "(หนี้ − เงินสด) / (กำไรดำเนินงาน + ค่าเสื่อมและตัดจำหน่าย); ต่ำดีกว่า"},
    "interest_coverage": {"label": "Interest Coverage", "weight": 5, "unit": "ratio", "direction": "higher", "group": "balance", "description": "กำไรดำเนินงาน / ดอกเบี้ยจ่าย; ถ้าเปิดเผยดอกเบี้ยเป็นศูนย์และมีกำไร กำหนดเพดาน 100 เท่า"},
    "shares_cagr": {"label": "จำนวนหุ้นเพิ่มต่อปี 5 ปี", "weight": 5, "unit": "percent", "direction": "lower", "group": "shareholder", "description": "CAGR 5 ปีของ diluted weighted average shares ปรับ split; ต่ำดีกว่า"},
}

WEIGHTS = {key: item["weight"] for key, item in METRIC_DEFS.items()}
assert sum(WEIGHTS.values()) == 100


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def percentile(value, values, direction="higher"):
    """Midrank percentile; ties get identical scores, singleton gets neutral 50.

    For distinct endpoints this maps min to 0 and max to 100. No clipping is
    required: ranks already contain the effect of extreme raw observations.
    """
    clean = [float(v) for v in values if finite(v)]
    if not finite(value) or not clean:
        return None
    if len(clean) == 1:
        return 50.0
    below = sum(v < value for v in clean)
    equal = sum(v == value for v in clean)
    result = 100.0 * (below + (equal - 1) / 2) / (len(clean) - 1)
    return round(100.0 - result if direction == "lower" else result, 4)


def cagr(values, years=5, require_all_positive=False):
    if len(values) != years + 1 or any(not finite(v) for v in values):
        return None
    if values[0] <= 0 or values[-1] <= 0:
        return None
    if require_all_positive and any(v <= 0 for v in values):
        return None
    return (values[-1] / values[0]) ** (1 / years) - 1


def compute_metrics(annual, price=None, split_events=None):
    """Compute from the latest six consecutive annual periods, no YTD summation.

    annual is oldest first. Each row contains end, filing_date and normalized
    financial values. EPS/shares are adjusted for splits AFTER the observation's
    filing date because later filings can already restate historical values.
    """
    annual = sorted(annual, key=lambda row: row["end"])
    latest = annual[-1] if annual else {}
    values = {key: None for key in METRIC_DEFS}
    reasons = {key: "ข้อมูลที่จำเป็นไม่ครบ" for key in METRIC_DEFS}
    periods = {}
    split_events = split_events or []

    def adjusted(row, key):
        val = row.get(key)
        if not finite(val):
            return None
        ratio = 1.0
        for event in split_events:
            if event["date"] > row.get(key + "_filed", row.get("filing_date", "9999")):
                ratio *= event["ratio"]
        return val / ratio if key == "eps" else val * ratio

    def present(row, *keys):
        return all(finite(row.get(k)) for k in keys)

    def continuous(rows, expected):
        if len(rows) != expected:
            return False
        return all(320 <= (date.fromisoformat(b["end"]) - date.fromisoformat(a["end"])).days <= 410
                   for a, b in zip(rows, rows[1:]))

    def set_metric(key, value, period, reason=None):
        if finite(value):
            values[key] = float(value)
            reasons[key] = reason
        elif reason:
            reasons[key] = reason
        periods[key] = period

    end = latest.get("end", "")
    fy = "FY " + end
    three, four, five, six = annual[-3:], annual[-4:], annual[-5:], annual[-6:]
    if continuous(four, 4):
        roics = []
        for prior, current in zip(four, four[1:]):
            if not (present(prior, "debt", "equity", "cash") and
                    present(current, "debt", "equity", "cash", "operating_income", "tax", "pretax")):
                break
            prior_ic = prior["debt"] + prior["equity"] - prior["cash"]
            current_ic = current["debt"] + current["equity"] - current["cash"]
            if min(prior_ic, current_ic) <= 0 or current["pretax"] <= 0:
                break
            tax_rate = current["tax"] / current["pretax"]
            if not 0 <= tax_rate <= 0.50:
                break
            roics.append(current["operating_income"] * (1 - tax_rate) / ((prior_ic + current_ic) / 2))
        set_metric("roic", mean(roics) if len(roics) == 3 else None,
                   four[1]["end"] + " – " + end,
                   None if len(roics) == 3 else "เงินลงทุนต้องเป็นบวกและมีอัตราภาษีที่เปรียบเทียบได้ครบ 3 ปี")
    if continuous(three, 3) and all(present(r, "cfo", "capex", "revenue") and r["revenue"] > 0 for r in three):
        set_metric("fcf_margin", mean((r["cfo"] - r["capex"]) / r["revenue"] for r in three), three[0]["end"] + " – " + end)
    if continuous(five, 5) and all(present(r, "operating_income", "revenue") and r["revenue"] > 0 for r in five):
        set_metric("operating_margin_stability", pstdev(r["operating_income"] / r["revenue"] for r in five), five[0]["end"] + " – " + end)
    if continuous(six, 6):
        period = six[0]["end"] + " – " + end
        set_metric("revenue_cagr", cagr([r.get("revenue") for r in six]), period)
        eps_values = [adjusted(r, "eps") for r in six]
        set_metric("eps_cagr", cagr(eps_values, require_all_positive=True), period,
                   None if cagr(eps_values, require_all_positive=True) is not None else "ต้องมี EPS บวกและข้อมูลครบทุกปีในช่วง 6 ปีงบประมาณ")
        set_metric("shares_cagr", cagr([adjusted(r, "shares") for r in six], require_all_positive=True), period)

    eps = adjusted(latest, "eps")
    shares = adjusted(latest, "shares")
    equity_value = price * shares if finite(price) and price > 0 and finite(shares) and shares > 0 else None
    if finite(price) and price > 0 and finite(eps) and eps > 0:
        set_metric("earnings_yield", eps / price, fy + " / ราคาปิดล่าสุด")
    else:
        reasons["earnings_yield"] = "ต้องมีราคาและ EPS เป็นบวก; P/E ติดลบใช้จัดอันดับไม่ได้"
    if equity_value and present(latest, "cfo", "capex"):
        set_metric("fcf_yield", (latest["cfo"] - latest["capex"]) / equity_value, fy + " / ราคาปิดล่าสุด")
    if equity_value and present(latest, "debt", "cash", "operating_income"):
        ev = equity_value + latest["debt"] - latest["cash"]
        if ev > 0 and latest["operating_income"] > 0:
            set_metric("ebit_ev", latest["operating_income"] / ev, fy + " / ราคาปิดล่าสุด")
    if present(latest, "debt", "cash", "operating_income", "da"):
        ebitda = latest["operating_income"] + latest["da"]
        if ebitda > 0:
            set_metric("net_debt_ebitda", (latest["debt"] - latest["cash"]) / ebitda, fy)
    if present(latest, "operating_income", "interest") and latest["operating_income"] > 0 and latest["interest"] >= 0:
        coverage = min(100.0, latest["operating_income"] / latest["interest"]) if latest["interest"] > 0 else 100.0
        set_metric("interest_coverage", coverage, fy)

    return {key: {**definition, "value": values[key], "score": None, "period": periods.get(key, fy),
                  "reason": reasons[key], "comparison_group": None, "sample_n": 0}
            for key, definition in METRIC_DEFS.items()}


def score_stocks(stocks, min_sector_peers=5):
    """Assign per-metric sector percentiles; fallback to this sample universe.

    All valid observations enter each comparison group, even where another
    metric is missing. No company is ranked until all positive-weight metrics
    exist. Small samples are disclosed with sample_n and a warning.
    """
    for stock in stocks:
        for key, definition in METRIC_DEFS.items():
            metric = stock["metrics"][key]
            if not finite(metric.get("value")):
                continue
            peers = [s["metrics"][key]["value"] for s in stocks
                     if s["sector"] == stock["sector"] and finite(s["metrics"][key].get("value"))]
            group = "sector: " + stock["sector"]
            if len(peers) < min_sector_peers:
                peers = [s["metrics"][key]["value"] for s in stocks if finite(s["metrics"][key].get("value"))]
                group = "sample universe"
            metric["score"] = percentile(metric["value"], peers, definition["direction"])
            metric["comparison_group"] = group
            metric["sample_n"] = len(peers)
        available = sum(WEIGHTS[k] for k in WEIGHTS if finite(stock["metrics"][k].get("value")))
        stock["coverage"] = available
        reasons = [stock["metrics"][k]["label"] + ": " + (stock["metrics"][k].get("reason") or "ข้อมูลไม่ครบ")
                   for k in WEIGHTS if not finite(stock["metrics"][k].get("value"))]
        stock["eligibility_reasons"] = reasons
        complete = available == 100 and all(finite(stock["metrics"][k].get("score")) for k in WEIGHTS)
        stock["status"] = "ranked" if complete else "unranked"
        stock["score"] = round(sum(stock["metrics"][k]["score"] * WEIGHTS[k] for k in WEIGHTS) / 100, 2) if complete else None
        for label, keys in (("valuation_score", [k for k, d in METRIC_DEFS.items() if d["group"] == "valuation"]),
                            ("business_score", [k for k, d in METRIC_DEFS.items() if d["group"] != "valuation"])):
            stock[label] = round(sum(stock["metrics"][k]["score"] * WEIGHTS[k] for k in keys) / sum(WEIGHTS[k] for k in keys), 2) if all(finite(stock["metrics"][k].get("score")) for k in keys) else None
        stock["rank"] = None
    ranked = sorted([s for s in stocks if s["status"] == "ranked"], key=lambda s: (-s["score"], s["ticker"]))
    for number, stock in enumerate(ranked, 1):
        stock["rank"] = number
    return sorted(stocks, key=lambda s: (s["score"] is None, -(s["score"] or 0), s["ticker"]))
