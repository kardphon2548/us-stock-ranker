#!/usr/bin/env python3
"""Refresh a static, auditable US equity screen. Python 3.10+, no packages.

SEC data are annual companyfacts, NOT TTM. Yahoo daily closes and corporate
actions are an unofficial best-effort input. The production --strict option
preserves the previous output if any source cannot be refreshed.
"""
from __future__ import annotations

import argparse
from datetime import date, datetime, timezone, timedelta
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

from scoring import METRIC_DEFS, WEIGHTS, compute_metrics, finite, score_stocks

ROOT = Path(__file__).resolve().parents[1]
ANNUAL_FORMS = {"10-K", "10-K/A", "20-F", "20-F/A"}
TAGS = {
    "revenue": ["RevenueFromContractWithCustomerExcludingAssessedTax", "RevenueFromContractWithCustomerIncludingAssessedTax", "Revenues", "SalesRevenueNet"],
    "operating_income": ["OperatingIncomeLoss"],
    "cfo": ["NetCashProvidedByUsedInOperatingActivities"],
    "capex": ["PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets"],
    "eps": ["EarningsPerShareDiluted", "EarningsPerShareBasicAndDiluted"],
    "shares": ["WeightedAverageNumberOfDilutedSharesOutstanding"],
    "tax": ["IncomeTaxExpenseBenefit"],
    "pretax": ["IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest", "IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments", "IncomeLossFromContinuingOperationsBeforeIncomeTaxes"],
    "interest": ["InterestExpenseNonoperating", "InterestAndDebtExpense", "InterestExpense", "InterestExpenseDebt"],
    "da": ["DepreciationDepletionAndAmortization", "DepreciationAmortizationAndAccretionNet", "DepreciationAndAmortization"],
    "depreciation": ["Depreciation"],
    "amortization": ["AmortizationOfIntangibleAssets"],
    "equity": ["StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"],
    "cash": ["CashAndCashEquivalentsAtCarryingValue"],
    "long_debt_total": ["LongTermDebtAndFinanceLeaseObligationsIncludingCurrentPortion", "LongTermDebtAndCapitalLeaseObligationsIncludingCurrentPortion", "LongTermDebt"],
    "long_debt_current": ["LongTermDebtCurrent", "LongTermDebtAndCapitalLeaseObligationsCurrent", "LongTermDebtAndFinanceLeaseObligationsCurrent"],
    "long_debt_noncurrent": ["LongTermDebtNoncurrent", "LongTermDebtAndCapitalLeaseObligations", "LongTermDebtAndFinanceLeaseObligationsNoncurrent"],
    "short_debt": ["ShortTermBorrowings", "ShortTermDebtCurrent", "CommercialPaper"],
}
INSTANT_KEYS = {"equity", "cash", "long_debt_total", "long_debt_current", "long_debt_noncurrent", "short_debt"}


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


class Fetcher:
    def __init__(self, cache_dir, force=False):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.force = force
        self.last_sec = 0
        self.last_yahoo = 0
        self.agent = os.getenv("SEC_USER_AGENT", "LongTermStockRanker research project contact@example.com")

    def get(self, url, kind):
        cache = self.cache_dir / (hashlib.sha256(url.encode()).hexdigest() + ".json")
        max_age = 20 * 3600 if kind == "sec" else 4 * 3600
        if not self.force and cache.exists() and time.time() - cache.stat().st_mtime < max_age:
            return load_json(cache)
        delay = (1.05 - (time.monotonic() - self.last_sec)) if kind == "sec" else (0.4 - (time.monotonic() - self.last_yahoo))
        if delay > 0:
            time.sleep(delay)
        headers = {"User-Agent": self.agent if kind == "sec" else "Mozilla/5.0 LongTermStockRanker/1.0", "Accept": "application/json"}
        failure = None
        for attempt in range(2):
            try:
                if kind == "sec":
                    self.last_sec = time.monotonic()
                else:
                    self.last_yahoo = time.monotonic()
                with urlopen(Request(url, headers=headers), timeout=30) as response:
                    payload = json.load(response)
                # Cache only validated JSON; failures must not replace a good cache.
                temporary = cache.with_suffix(".tmp")
                temporary.write_text(json.dumps(payload), encoding="utf-8")
                temporary.replace(cache)
                return payload
            except (HTTPError, URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
                failure = exc
                if attempt == 0:
                    time.sleep(2)
        raise RuntimeError(str(failure))


def fact_series(companyfacts, tags, unit="USD", instant=False, as_of=None):
    """Latest disclosed value per annual end, respecting annual period length.

    10-Q cash flow facts can be cumulative YTD; they are deliberately excluded.
    Fallback aliases are selected independently for each period. Restatements
    remain traceable to accession, filing date, and original taxonomy tag.
    """
    today = as_of or date.today().isoformat()
    facts = companyfacts.get("facts", {}).get("us-gaap", {})
    output = {}
    for priority, tag in enumerate(tags):
        records = facts.get(tag, {}).get("units", {}).get(unit, [])
        by_end = {}
        for raw in records:
            if raw.get("form") not in ANNUAL_FORMS or raw.get("filed", "9999") > today or not finite(raw.get("val")):
                continue
            end = raw.get("end")
            if not end:
                continue
            if not instant:
                try:
                    days = (date.fromisoformat(end) - date.fromisoformat(raw["start"])).days
                except (KeyError, ValueError):
                    continue
                if not 330 <= days <= 380:
                    continue
            elif raw.get("start"):
                continue
            previous = by_end.get(end)
            if previous is None or (raw.get("filed", ""), raw.get("accn", "")) > (previous.get("filed", ""), previous.get("accn", "")):
                by_end[end] = {**raw, "tag": tag, "unit": unit, "_priority": priority}
        for end, record in by_end.items():
            previous = output.get(end)
            if previous is None or (record.get("filed", ""), record.get("accn", ""), -priority) > (previous.get("filed", ""), previous.get("accn", ""), -previous["_priority"]):
                output[end] = record
    return output


def normalize_annual(companyfacts):
    series = {}
    for key, tags in TAGS.items():
        unit = "USD/shares" if key == "eps" else "shares" if key == "shares" else "USD"
        series[key] = fact_series(companyfacts, tags, unit=unit, instant=key in INSTANT_KEYS)
    ends = sorted(series["revenue"])[-6:]
    annual = []
    for end in ends:
        revenue_fact = series["revenue"][end]
        row = {"end": end, "start": revenue_fact["start"], "filing_date": revenue_fact["filed"], "sources": {}}
        for key, by_end in series.items():
            if end in by_end:
                record = by_end[end]
                row[key] = record["val"]
                row[key + "_filed"] = record["filed"]
                row["sources"][key] = {"tag": record["tag"], "accession": record.get("accn"), "filed": record["filed"], "start": record.get("start"), "end": record["end"], "unit": record["unit"], "evidence_label": "fact_source_reported"}
        # Explicit total first, otherwise sum non-overlapping current/noncurrent.
        long_total = row.get("long_debt_total")
        if long_total is None and finite(row.get("long_debt_current")) and finite(row.get("long_debt_noncurrent")):
            long_total = row["long_debt_current"] + row["long_debt_noncurrent"]
        if finite(long_total):
            # Missing standalone short-term borrowings is not proof of zero.
            # Reported total debt here is long-term obligations plus disclosed
            # short-term borrowings. Every issuer gets an approximation flag.
            row["debt"] = long_total + (row.get("short_debt") or 0)
        # Depreciation and intangible amortization are disjoint line items.
        # Require BOTH; a missing intangible item is never presumed to be zero.
        if not finite(row.get("da")) and finite(row.get("depreciation")) and finite(row.get("amortization")):
            row["da"] = row["depreciation"] + row["amortization"]
            row["sources"]["da"] = {"evidence_label": "derived_calculation", "method": "Depreciation + AmortizationOfIntangibleAssets", "end": end, "unit": "USD"}
        annual.append(row)
    return annual


def parse_price(payload, now=None):
    now = now or datetime.now(timezone.utc)
    chart = payload.get("chart", {})
    if chart.get("error") or not chart.get("result"):
        raise ValueError("Yahoo chart ไม่มีข้อมูลราคา")
    result = chart["result"][0]
    meta = result.get("meta", {})
    if meta.get("currency") != "USD":
        raise ValueError("ราคาไม่ได้ระบุหน่วย USD")
    timestamps = result.get("timestamp", [])
    quotes = result.get("indicators", {}).get("quote", [{}])[0].get("close", [])
    offset = meta.get("gmtoffset", -14400)
    session = meta.get("currentTradingPeriod", {}).get("regular", {})
    closes = []
    for timestamp, close in zip(timestamps, quotes):
        if not finite(close) or close <= 0:
            continue
        # The current daily candle is unfinished before the regular session end.
        if session.get("start", 10**15) <= timestamp and now.timestamp() < session.get("end", 0):
            continue
        closes.append((timestamp, close))
    if not closes:
        raise ValueError("ไม่พบราคาปิดรายวันที่สมบูรณ์")
    timestamp, close = closes[-1]
    price_day = datetime.fromtimestamp(timestamp + offset, timezone.utc).date().isoformat()
    events = []
    for event in result.get("events", {}).get("splits", {}).values():
        numerator, denominator = event.get("numerator"), event.get("denominator")
        if finite(numerator) and finite(denominator) and denominator > 0:
            day = datetime.fromtimestamp(event["date"] + offset, timezone.utc).date().isoformat()
            events.append({"date": day, "ratio": numerator / denominator})
    return {"price": close, "price_as_of": price_day, "splits": sorted(events, key=lambda e: e["date"]), "currency": "USD"}


def collect(universe, fetcher):
    stocks, failures = [], []
    for index, security in enumerate(universe, 1):
        ticker = security["ticker"]
        cik = str(security["cik"]).zfill(10)
        sec_url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json"
        yahoo_url = f"https://query1.finance.yahoo.com/v8/finance/chart/{quote(ticker)}?range=10y&interval=1d&events=splits"
        stock = {**security, "cik": cik, "price": None, "price_as_of": None, "financial_as_of": None, "filing_date": None, "hard_exclusion": False,
                 "financial_period": None, "warnings": [], "source_urls": {"financials": sec_url, "price": f"https://finance.yahoo.com/quote/{quote(ticker)}/history/"}}
        annual, splits = [], []
        try:
            facts = fetcher.get(sec_url, "sec")
            annual = normalize_annual(facts)
            if not annual:
                raise ValueError("ไม่พบงบรายปีมาตรฐาน US GAAP ที่ใช้ได้")
            latest = annual[-1]
            stock.update({"financial_as_of": latest["end"], "filing_date": latest["filing_date"], "financial_period": "FY " + latest["end"],
                          "financial_history": annual, "financial_source": "SEC EDGAR companyfacts / US GAAP"})
            stock["warnings"].append("ใช้ปีงบล่าสุด (FY) ไม่ใช่ TTM; แต่ละบริษัทอาจมีวันสิ้นปีต่างกัน")
            stock["warnings"].append("หนี้: รวม long-term debt และ short-term borrowings ที่เปิดเผย; ไม่รวม lease ที่แยกรายการและภาระนอกงบทั้งหมด")
            if any(not finite(r.get("short_debt")) for r in annual):
                stock["warnings"].append("บางปีไม่มี short-term borrowings แยกในแท็กมาตรฐาน; หนี้ที่คำนวณอาจต่ำกว่าหนี้จริง")
        except (RuntimeError, ValueError, KeyError, TypeError) as exc:
            text = f"{ticker}: SEC fetch/normalization failed: {exc}"
            failures.append(text)
            stock["warnings"].append("ดึงงบไม่สำเร็จ: " + str(exc))
        try:
            data = parse_price(fetcher.get(yahoo_url, "yahoo"))
            stock.update({"price": data["price"], "price_as_of": data["price_as_of"], "currency": "USD"})
            splits = data["splits"]
            age = (date.today() - date.fromisoformat(data["price_as_of"])).days
            if age > 5:
                stock["warnings"].append(f"ราคาปิดเก่ากว่า 5 วัน ({age} วัน)")
                failures.append(f"{ticker}: price is {age} calendar days old")
        except (RuntimeError, ValueError, KeyError, TypeError) as exc:
            failures.append(f"{ticker}: price fetch failed: {exc}")
            stock["warnings"].append("ดึงราคาไม่สำเร็จ: " + str(exc))
        stock["metrics"] = compute_metrics(annual, stock["price"], splits)
        if stock["price"] is None:
            for key in ("eps_cagr", "shares_cagr"):
                stock["metrics"][key].update({"value": None, "reason": "ต้องมีข้อมูล stock split จากแหล่งราคาเพื่อเทียบต่อหุ้นย้อนหลัง"})
        ey = stock["metrics"]["earnings_yield"]["value"]
        stock["pe"] = round(1 / ey, 3) if finite(ey) and ey > 0 else None
        stock["warnings"].append("Market cap/EV ใช้ diluted shares เฉลี่ยปีงบล่าสุด จึงเป็นค่าประมาณ")
        if annual and (date.today() - date.fromisoformat(annual[-1]["end"])).days > 550:
            stock["hard_exclusion"] = True
            stock["warnings"].append("งบล่าสุดเก่ากว่า 550 วัน; พักอันดับ")
            for metric in stock["metrics"].values():
                metric.update({"value": None, "reason": "งบล้าสมัยเกินเกณฑ์ 550 วัน"})
        stocks.append(stock)
        print(f"[{index:02d}/{len(universe):02d}] {ticker}: financials={stock['financial_as_of']} close={stock['price_as_of']}", flush=True)
    return score_stocks(stocks), failures


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--universe", type=Path, default=ROOT / "scripts" / "universe.json")
    parser.add_argument("--output", type=Path, default=ROOT / "dist" / "data" / "latest.json")
    parser.add_argument("--cache-dir", type=Path, default=ROOT / ".cache")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--strict", action="store_true", help="Any raw source failure preserves the prior snapshot and exits 1")
    parser.add_argument("--allow-empty", action="store_true", help="Write an explicitly empty diagnostic snapshot even if all sources fail")
    args = parser.parse_args(argv)
    universe = load_json(args.universe)
    if args.limit:
        universe = universe[:args.limit]
    if not universe:
        parser.error("Universe must not be empty")
    if not os.getenv("SEC_USER_AGENT"):
        print("Warning: set SEC_USER_AGENT to 'Project name contact@your-domain' before scheduling.", file=sys.stderr)
    stocks, failures = collect(universe, Fetcher(args.cache_dir, args.force))
    usable = any(s["financial_as_of"] and s["price_as_of"] for s in stocks)
    if (args.strict and failures) or (not usable and not args.allow_empty):
        print("Refresh failed; previous latest.json preserved.\n" + "\n".join(failures), file=sys.stderr)
        return 1
    metadata = {"generated_at": utc_now(), "mode": "annual_fy", "model_version": "1.0.0", "status": "partial" if failures else "ready",
                "source": "SEC EDGAR annual companyfacts + Yahoo Finance daily chart (unofficial)",
                "universe_count": len(universe), "ranked_count": sum(s["status"] == "ranked" for s in stocks),
                "warnings": ["ตัวอย่างหุ้นคัดไว้ล่วงหน้า ไม่ใช่หุ้นสหรัฐทั้งหมด; มี selection/survivorship bias",
                             "คะแนนสัมพัทธ์จากตัวอย่างนี้; เปรียบเทียบ sector ถ้ามีข้อมูลอย่างน้อย 5 บริษัท มิฉะนั้นใช้ทั้ง sample universe",
                             "งบเป็น FY ไม่ใช่ TTM; ราคาปิดรายวันจากแหล่งไม่เป็นทางการ ไม่รับประกันความต่อเนื่อง",
                             "คะแนนเป็นโมเดลเริ่มต้น ยังไม่ผ่าน point-in-time backtest; ใช้คัดหุ้นไปศึกษาต่อ",
                             "การเปลี่ยนหุ้นใน universe อาจเปลี่ยนคะแนน แม้ตัวเลขบริษัทไม่เปลี่ยน"],
                "failures": failures, "weights": WEIGHTS, "metric_defs": METRIC_DEFS,
                "normalization_notes": ["FCF = operating cash flow − capex; no summation of YTD cash-flow observations",
                                        "Stock splits after source filing dates adjust EPS and diluted shares",
                                        "ROIC uses positive average debt+equity−cash; effective tax rate must be between 0% and 50%",
                                        "Price-derived values use annual diluted shares as a disclosed approximation, not current shares outstanding",
                                        "Interest coverage capped at 100; missing reported interest is not assumed zero",
                                        "Sector labels and sample universe are manually maintained; no financials or REITs"]}
    payload = {"metadata": metadata, "stocks": stocks}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(args.output)
    print(f"Wrote {args.output}: {metadata['ranked_count']}/{len(stocks)} ranked; {len(failures)} source failures.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
